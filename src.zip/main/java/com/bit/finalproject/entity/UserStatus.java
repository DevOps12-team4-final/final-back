package com.bit.finalproject.entity;

public enum UserStatus {
    // 활동중
    ACTIVE,
    // 비활동중
    INACTIVE,
    // 정지
    BANNED,
    // 탈퇴
    WITHDRAWN
}
