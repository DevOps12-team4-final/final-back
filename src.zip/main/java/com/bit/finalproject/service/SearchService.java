package com.bit.finalproject.service;

import java.util.List;

public interface SearchService {
    List<?> searchByUser(String searchKeyword);
}
